﻿namespace TestingApp.ViewModels
{
    public class VendingItems
    {
        public int Slot { get; set; }
        public int Amount { get; set; }
    }
}
