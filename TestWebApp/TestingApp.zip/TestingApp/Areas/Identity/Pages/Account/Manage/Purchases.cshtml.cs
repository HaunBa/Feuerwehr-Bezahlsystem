using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace TestingApp.Areas.Identity.Pages.Account.Manage
{
    public class PurchasesModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
